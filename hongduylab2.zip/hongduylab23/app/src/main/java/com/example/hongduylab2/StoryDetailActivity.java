package com.example.hongduylab2;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.TextView;

public class StoryDetailActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_story_detail);

        TextView tv = findViewById(R.id.tvDetail);
        String name = getIntent().getStringExtra("name");
        setTitle(name);

        if (name.equals("Việc học")) {
            tv.setText("Lúc bé thì tưởng học là chơi, lớn lên mới biết học là học...");
        } else if (name.equals("Cười 1 phút")) {
            tv.setText("Một phút để cười là một phút không phí...");
        } else {
            tv.setText("Chưa chi đã đau là tình trạng...");
        }
    }
}
