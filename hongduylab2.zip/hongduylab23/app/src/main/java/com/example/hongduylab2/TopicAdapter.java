package com.example.hongduylab2;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

public class TopicAdapter extends ArrayAdapter<String> {

    Context context;
    String[] titles;
    int icon;

    public TopicAdapter(Context ctx, String[] titles, int icon) {
        super(ctx, R.layout.item_topic, titles);
        this.context = ctx;
        this.titles = titles;
        this.icon = icon;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        View row = LayoutInflater.from(context).inflate(R.layout.item_topic, parent, false);
        TextView tv = row.findViewById(R.id.tvTopic);
        ImageView img = row.findViewById(R.id.imgTopic);

        tv.setText(titles[position]);
        img.setImageResource(icon);

        return row;
    }
}
