package com.example.hongduylab2;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.content.Intent;

public class StoryListActivity extends AppCompatActivity {

    String[] stories = {"Việc học", "Cười 1 phút", "Chưa chi đã đau"};

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_story_list);

        ListView list = findViewById(R.id.listStory);
        list.setAdapter(new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, stories));

        list.setOnItemClickListener((parent, view, position, id) -> {
            Intent intent = new Intent(StoryListActivity.this, StoryDetailActivity.class);
            intent.putExtra("name", stories[position]);
            startActivity(intent);
        });
    }
}
