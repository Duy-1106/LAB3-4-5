package com.example.hongduylab2;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.ListView;
import android.content.Intent;

public class MainActivity extends AppCompatActivity {

    String[] topics = {"Con gái", "Công sở", "Cười 18", "Cực hài", "Gia đình", "Học sinh"};
    int icon = R.drawable.ic_smile; // Dùng duy nhất một icon

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        ListView list = findViewById(R.id.listTopic);
        TopicAdapter adapter = new TopicAdapter(this, topics, icon);
        list.setAdapter(adapter);

        list.setOnItemClickListener((adapterView, view, i, l) -> {
            Intent intent = new Intent(MainActivity.this, StoryListActivity.class);
            intent.putExtra("topic", topics[i]);
            startActivity(intent);
        });
    }
}
