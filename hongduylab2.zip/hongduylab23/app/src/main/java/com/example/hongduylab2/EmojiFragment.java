package com.example.hongduylab2;

import android.os.Bundle;
import android.os.Handler;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.Toast;
import androidx.fragment.app.Fragment;

public class EmojiFragment extends Fragment {

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_emoji, container, false);

        int[] emojiIDs = {
                R.id.e1, R.id.e2, R.id.e3,
                R.id.e4, R.id.e5, R.id.e6,
                R.id.e7, R.id.e8, R.id.e9
        };

        for (int id : emojiIDs) {
            ImageView img = view.findViewById(id);
            img.setOnClickListener(v -> {
                Toast t = Toast.makeText(getActivity(), "Bạn chọn emoji 😄", Toast.LENGTH_SHORT);
                t.show();
                new Handler().postDelayed(t::cancel, 1500);
            });
        }

        return view;
    }
}
