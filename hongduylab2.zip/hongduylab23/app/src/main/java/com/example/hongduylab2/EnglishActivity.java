package com.example.hongduylab2;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.ListView;

public class EnglishActivity extends AppCompatActivity {

    String[] topics = {
            "Essentials",
            "While Traveling",
            "Help / Medical",
            "At the Hotel",
            "At the Restaurant",
            "At the Bar",
            "At the Store",
            "At Work",
            "Time, Date, Numbers",
            "Education",
            "Entertainment"
    };

    int[] icons = {
            R.drawable.ic_essentials,
            R.drawable.ic_travel,
            R.drawable.ic_medical,
            R.drawable.ic_hotel,
            R.drawable.ic_restaurant,
            R.drawable.ic_bar,
            R.drawable.ic_store,
            R.drawable.ic_work,
            R.drawable.ic_time,
            R.drawable.ic_education,
            R.drawable.ic_entertainment
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_english);

        ListView listView = findViewById(R.id.listVocab);
        VocabAdapter adapter = new VocabAdapter(this, topics, icons);
        listView.setAdapter(adapter);
    }
}
