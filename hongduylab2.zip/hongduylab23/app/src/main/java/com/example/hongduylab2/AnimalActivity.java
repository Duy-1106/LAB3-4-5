package com.example.hongduylab2;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.Button;
import android.widget.Switch;
import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.widget.ImageView;
import android.widget.TextView;

public class AnimalActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_animal);

        TextView tvName = findViewById(R.id.tvName);
        TextView tvDescription = findViewById(R.id.tvDescription);
        ImageView imgAnimal = findViewById(R.id.imgAnimal);
        Switch swRotate = findViewById(R.id.swRotate);
        Button btnToTruyen = findViewById(R.id.btnToTruyen);
        Button btnToHome = findViewById(R.id.btnToHome);

        tvName.setText("Rabbit");
        tvDescription.setText("Rabbits are small mammals known for soft fur and long ears.");
        imgAnimal.setImageResource(R.drawable.rabbit);

        // Xoay màn hình ON/OFF
        swRotate.setOnCheckedChangeListener((buttonView, isChecked) -> {
            if (isChecked) {
                setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED);
            } else {
                setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);
            }
        });

        // Chuyển sang Truyện Cười
        btnToTruyen.setOnClickListener(v ->
                startActivity(new Intent(AnimalActivity.this, MainActivity.class))
        );

        // Quay về menu chính
        btnToHome.setOnClickListener(v ->
                startActivity(new Intent(AnimalActivity.this, HomeActivity.class))
        );
    }
}
