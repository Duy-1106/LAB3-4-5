package com.example.hongduylab2;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.Switch;
import android.content.pm.ActivityInfo;

public class HomeActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);

        Button btnTruyen = findViewById(R.id.btnTruyenCuoi);
        Button btnAnimal = findViewById(R.id.btnAnimal);
        Switch swRotate = findViewById(R.id.swRotate);

        // Dẫn sang activity Truyện Cười
        btnTruyen.setOnClickListener(v ->
                startActivity(new Intent(HomeActivity.this, MainActivity.class))
        );
        Button btnEmoji = findViewById(R.id.btnEmoji);
        btnEmoji.setOnClickListener(v -> {
            getSupportFragmentManager()
                    .beginTransaction()
                    .replace(android.R.id.content, new EmojiFragment())
                    .addToBackStack(null)
                    .commit();
        });

        Button btnAnimation = findViewById(R.id.btnAnimation);
        btnAnimation.setOnClickListener(v -> {
            startActivity(new Intent(HomeActivity.this, AnimationActivity.class));
        });

        // Dẫn sang activity Animal
        btnAnimal.setOnClickListener(v ->
                startActivity(new Intent(HomeActivity.this, AnimalActivity.class))
        );
        Button btnEnglish = findViewById(R.id.btnEnglish);

        btnEnglish.setOnClickListener(v ->
                startActivity(new Intent(HomeActivity.this, EnglishActivity.class))
        );

        // Bật / tắt xoay màn hình
        swRotate.setOnCheckedChangeListener((buttonView, isChecked) -> {
            if (isChecked) {
                // Cho xoay tự do
                setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED);
            } else {
                // Khóa xoay, chỉ cho đứng
                setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);
            }
        });
    }
}
