package com.example.hongduylab2;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.content.Intent;
import android.view.animation.AlphaAnimation;
import android.view.animation.Animation;
import android.view.animation.RotateAnimation;
import android.view.animation.ScaleAnimation;
import android.view.animation.TranslateAnimation;
import android.widget.Button;
import android.widget.ImageView;

public class AnimationActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_animation);

        ImageView img = findViewById(R.id.imgAnimal);
        Button btnAlpha = findViewById(R.id.btnAlpha);
        Button btnScale = findViewById(R.id.btnScale);
        Button btnTrans = findViewById(R.id.btnTrans);
        Button btnRotate = findViewById(R.id.btnRotate);

        btnAlpha.setOnClickListener(v -> {
            AlphaAnimation anim = new AlphaAnimation(0.1f, 1.0f);
            anim.setDuration(1000);
            anim.setRepeatCount(Animation.INFINITE);
            img.startAnimation(anim);
        });

        btnScale.setOnClickListener(v -> {
            ScaleAnimation anim = new ScaleAnimation(
                    1, 1.5f, 1, 1.5f,
                    Animation.RELATIVE_TO_SELF, 0.5f,
                    Animation.RELATIVE_TO_SELF, 0.5f);
            anim.setDuration(800);
            anim.setRepeatCount(Animation.INFINITE);
            img.startAnimation(anim);
        });

        btnTrans.setOnClickListener(v -> {
            TranslateAnimation anim = new TranslateAnimation(0, 0, 0, 100);
            anim.setDuration(900);
            anim.setRepeatCount(Animation.INFINITE);
            anim.setRepeatMode(Animation.REVERSE);
            img.startAnimation(anim);
        });

        btnRotate.setOnClickListener(v -> {
            RotateAnimation anim = new RotateAnimation(
                    0, 360,
                    Animation.RELATIVE_TO_SELF, 0.5f,
                    Animation.RELATIVE_TO_SELF, 0.5f);
            anim.setDuration(1200);
            anim.setRepeatCount(Animation.INFINITE);
            img.startAnimation(anim);
        });
    }
}
