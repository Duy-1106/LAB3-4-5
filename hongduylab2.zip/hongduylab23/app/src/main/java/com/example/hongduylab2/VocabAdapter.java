package com.example.hongduylab2;

import android.content.Context;
import android.view.View;
import android.view.ViewGroup;
import android.widget.*;

public class VocabAdapter extends BaseAdapter {
    Context context;
    String[] title;
    int[] icons;

    public VocabAdapter(Context context, String[] title, int[] icons) {
        this.context = context;
        this.title = title;
        this.icons = icons;
    }

    @Override
    public int getCount() { return title.length; }

    @Override
    public Object getItem(int i) { return title[i]; }

    @Override
    public long getItemId(int i) { return i; }

    @Override
    public View getView(int i, View view, ViewGroup parent) {
        if(view == null)
            view = View.inflate(context, R.layout.item_vocab, null);

        ImageView img = view.findViewById(R.id.imgIcon);
        TextView tv = view.findViewById(R.id.tvTitle);

        img.setImageResource(icons[i]);
        tv.setText(title[i]);

        return view;
    }
}
